/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package BSTString;


public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        BSTreeString tree = new BSTreeString();
        String[] a = {"D", "B", "F", "A", "C", "E", "G"};
        //              D         
        //           B     F
        //         A   C E   G
        System.out.print("Array of tree : ");
        for (int i = 0; i < a.length; i++) {
            System.out.print(a[i] + " ");
        }
        tree.addArray(a);
        System.out.print("\nBreadth traversal: ");
        tree.breadth();
        System.out.print("\nPreorder traversal: ");
        tree.preOrder(tree.root);
        System.out.print("\nInorder traversal: ");
        tree.inOrder(tree.root);
        System.out.print("\nPostorder traversal: ");
        tree.postOrder(tree.root);
        System.out.println("\nCount: " + tree.count());
        tree.deleteByMerging("F");
        System.out.print("Inorder after delete F:");
        tree.inOrder(tree.root);
        System.out.print("\nMin: " + tree.min().getData());
        System.out.print("\nMax: " + tree.max().getData());
       
        System.out.print("\nHeight: " + tree.height());
        if (tree.isBalanced()) {
            System.out.print("\n17.Tree is balanced");
        } else {
            System.out.print("\n17.Tree is not balanced");
        }
        if (tree.isHeap()) {
            System.out.print("\n19.Given binary tree is a Heap");
        } else {
            System.out.println("\n19.Given binary tree is not a Heap");
        }

        
    }
    
}
