/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab1_q1;

/**
 *
 * @author baohc
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       MyList list = new MyList();
       Node n  = new Node();
       
       list.addToHead(30);
       list.addToHead(40);
       list.addToTail(10);
       list.traverse();
       n = list.search(10);
       list.addBefore(n, 20);
       list.traverse();
      
    }
    
}
