
/**
 *
 * @author TrongPs
 */
public class Node {
    int item;
  char c;
  Node left;
  Node right;
}
