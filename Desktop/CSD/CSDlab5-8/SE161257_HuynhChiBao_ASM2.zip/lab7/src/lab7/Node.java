/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab7;


public class Node {
    Student student;
    Node next;
    Node(Student student){
        this.student = student;
        this.next = null;
    }
}
